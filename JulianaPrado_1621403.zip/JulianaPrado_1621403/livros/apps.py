from django.apps import AppConfig


class LivrosConfig(AppConfig):
    name = 'livros'
